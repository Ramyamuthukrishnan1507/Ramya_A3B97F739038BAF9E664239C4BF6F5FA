'''Implement a class called palyer that represents a cricket player. the player should have a
method called play() with prints "The player is playing cricket.Derive two classes, Batsman and
Bowler, from the player class override the player() mothod in each derived class in print()"The Batsman
is batting" and "The bowler is bowling", respectively. write a program to create object of both the
Batsman and Bowler classes and call the play() method for each object.'''


#define the base class player
class player:
  def play(self):
    print("The player is playing cricket.")

#define the derived class Barsman
class Batsman(player):
  def play(self):
    print("The Batsman is batting.")

#define the derived class Bowler
class Bowler(player):
  def play(self):
    print("The bowler is bowling.")
 
#create objects of batsman and bowler classes 
batsman = Batsman()
bowler = Bowler()

#call the play() method for each object 
batsman.play()
bowler.play()
